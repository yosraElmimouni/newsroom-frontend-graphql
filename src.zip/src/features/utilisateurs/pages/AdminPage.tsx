import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import '../style/admin.css';
import { useUsers } from '../data/usersData';

import { getUserInitials } from '../data/mockUser';
import { STATUS_LABEL, STATUS_BADGE_CLASS } from '../../articles/data/mockArticle';
import type { CategorieArticle } from '../../articles/types';
import { useAuth } from '../../../core/auth/useAuth';
import { AreaTrendChart, BarBreakdownChart, Sparkline } from '../composants/DashboardCharts';
import { useArticles } from '../../articles/data/articlesData';

const CATEGORY_META: Record<CategorieArticle, { label: string; emoji: string; color: string }> = {
  POLITIQUE: { label: 'Politique', emoji: '🏛️', color: '#2563eb' },
  ECONOMIE: { label: 'Économie', emoji: '💶', color: '#0f766e' },
  TECHNOLOGIE: { label: 'Technologie', emoji: '💻', color: '#7c3aed' },
  SPORT: { label: 'Sport', emoji: '⚽', color: '#ea580c' },
  CULTURE: { label: 'Culture', emoji: '🎭', color: '#be185d' },
  SANTE: { label: 'Santé', emoji: '🏥', color: '#dc2626' },
  EDUCATION: { label: 'Éducation', emoji: '🎓', color: '#0891b2' },
  ENVIRONNEMENT: { label: 'Environnement', emoji: '🌱', color: '#15803d' },
  INTERNATIONAL: { label: 'International', emoji: '🌍', color: '#4338ca' },
  SOCIETE: { label: 'Société', emoji: '🏙️', color: '#b45309' },
  SCIENCE: { label: 'Science', emoji: '🔬', color: '#0d9488' },
  SECURITE: { label: 'Sécurité', emoji: '🚨', color: '#b91c1c' },
  DIVERTISSEMENT: { label: 'Divertissement', emoji: '🎬', color: '#c026d3' },
  AUTRE: { label: 'Autre', emoji: '📰', color: '#64748b' },
};

const ROLE_BADGE_CLASS: Record<string, string> = {
  ADMIN: 'role-admin',
  JOURNALISTE: 'role-journaliste',
  EQUIPE_MEDIA: 'role-equipe-media',
  CELLULE_VALIDATION: 'role-cellule-validation',
};

const dayFormatter = new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: '2-digit' });
const dateFormatter = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });

/** Construit les 7 derniers jours (aujourd'hui inclus), du plus ancien au plus récent. */
function lastSevenDays(): Date[] {
  return Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - (6 - i));
    return d;
  });
}

function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export default function AdminPage() {
  const { user } = useAuth();
  const { users, loading: usersLoading, error: usersError } = useUsers();
  const { articles, loading: articlesLoading, error: articlesError } = useArticles();

  const loading = usersLoading || articlesLoading;
  const error = usersError ?? articlesError;

  const stats = useMemo(() => {
    const days = lastSevenDays();

    const usersPerDay = days.map((day) => users.filter((u) => isSameDay(new Date(u.dateCreation), day)).length);
    const articlesPerDay = days.map(
      (day) => articles.filter((a) => isSameDay(new Date(a.dateCreation), day)).length,
    );

    // Séries cumulées : point de départ = utilisateurs/articles déjà créés avant la fenêtre de 7 jours.
    const usersBefore = users.filter((u) => new Date(u.dateCreation) < days[0]).length;
    const articlesBefore = articles.filter((a) => new Date(a.dateCreation) < days[0]).length;

    const usersCumulative = usersPerDay.reduce<number[]>((acc, count, i) => {
      acc.push((i === 0 ? usersBefore : acc[i - 1]) + count);
      return acc;
    }, []);
    const articlesCumulative = articlesPerDay.reduce<number[]>((acc, count, i) => {
      acc.push((i === 0 ? articlesBefore : acc[i - 1]) + count);
      return acc;
    }, []);

    const activeUsers = users.filter((u) => u.statut === 'ACTIF').length;
    const pendingArticles = articles.filter(
      (a) => a.statut === 'En attente' || a.statut === 'EnCoursDeValidation',
    ).length;
    const publishedArticles = articles.filter((a) => a.statut === 'Publié').length;

    const categoryCounts = new Map<CategorieArticle, number>();
    articles.forEach((a) => {
      categoryCounts.set(a.categorie, (categoryCounts.get(a.categorie) ?? 0) + 1);
    });
    const topCategories = Array.from(categoryCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([categorie, value]) => ({
        label: CATEGORY_META[categorie]?.label ?? categorie,
        value,
        color: CATEGORY_META[categorie]?.color,
      }));

    const activityByDay = days.map((day, i) => ({
      label: dayFormatter.format(day),
      value: articlesPerDay[i],
    }));

    const recentUsers = [...users]
      .sort((a, b) => new Date(b.dateCreation).getTime() - new Date(a.dateCreation).getTime())
      .slice(0, 5);

    const recentArticles = [...articles]
      .sort((a, b) => new Date(b.dateCreation).getTime() - new Date(a.dateCreation).getTime())
      .slice(0, 5);

    const featuredArticles = recentArticles.slice(0, 4);

    return {
      totalUsers: users.length,
      totalArticles: articles.length,
      activeUsers,
      pendingArticles,
      publishedArticles,
      usersSparkline: usersCumulative.map((value) => ({ value })),
      articlesSparkline: articlesCumulative.map((value) => ({ value })),
      topCategories,
      activityByDay,
      recentUsers,
      recentArticles,
      featuredArticles,
    };
  }, [users, articles]);

  if (loading) return <div className="page">Chargement du tableau de bord...</div>;
  if (error) return <div className="page">Erreur lors du chargement du tableau de bord : {error.message}</div>;

  return (
    <div className="page dashboard-page">
      <div>
        <h1 className="page-title">Bonjour, {user?.nom ?? 'Admin'} 👋</h1>
        <p className="page-subtitle">Suivez l'activité de la rédaction, les publications et les comptes en temps réel.</p>
      </div>

      {/* Cartes KPI */}
      <div className="stat-grid">
        <div className="stat-card">
          <p className="stat-label">Utilisateurs</p>
          <div className="stat-body">
            <p className="stat-value">{stats.totalUsers}</p>
            <Sparkline data={stats.usersSparkline} color="var(--brand-accent)" />
          </div>
          <p className="stat-footnote">{stats.activeUsers} actifs sur {stats.totalUsers}</p>
        </div>

        <div className="stat-card">
          <p className="stat-label">Articles</p>
          <div className="stat-body">
            <p className="stat-value">{stats.totalArticles}</p>
            <Sparkline data={stats.articlesSparkline} color="var(--brand-success)" />
          </div>
          <p className="stat-footnote">{stats.publishedArticles} publiés au total</p>
        </div>

        <div className="stat-card">
          <p className="stat-label">En attente de validation</p>
          <p className="stat-value">{stats.pendingArticles}</p>
          <p className={`stat-footnote ${stats.pendingArticles > 0 ? 'stat-footnote-warning' : ''}`}>
            {stats.pendingArticles > 0 ? 'À traiter par la cellule de validation' : 'Aucun article en attente'}
          </p>
        </div>

        <div className="stat-card">
          <p className="stat-label">Utilisateurs actifs</p>
          <p className="stat-value">{stats.activeUsers}</p>
          <p className="stat-footnote">{stats.totalUsers - stats.activeUsers} comptes inactifs</p>
        </div>
      </div>

      {/* Derniers articles créés */}
      <div>
        <div className="section-header-row">
          <p className="section-title">Derniers articles</p>
          <Link to="/articles" className="section-link">Voir tous les articles →</Link>
        </div>
        <div className="article-card-grid">
          {stats.featuredArticles.map((article) => {
            const meta = CATEGORY_META[article.categorie];
            return (
              <Link key={article.id} to={`/article/${article.id}`} className="article-card">
                <div className="article-card-cover" style={{ background: `linear-gradient(135deg, ${meta.color}, ${meta.color}cc)` }}>
                  <span className="article-card-emoji">{meta.emoji}</span>
                  <span className={`status-badge article-card-status ${STATUS_BADGE_CLASS[article.statut]}`}>
                    {STATUS_LABEL[article.statut]}
                  </span>
                </div>
                <div className="article-card-body">
                  <p className="article-card-title">{article.titre}</p>
                  <p className="article-card-author">{article.auteur.prenom} {article.auteur.nom}</p>
                  <span className="article-card-category">{meta.label}</span>
                </div>
              </Link>
            );
          })}
          {stats.featuredArticles.length === 0 && <p className="empty-state">Aucun article pour le moment.</p>}
        </div>
      </div>

      {/* Graphiques */}
      <div className="chart-row">
        <div className="card chart-card">
          <p className="card-title">Publications (7 derniers jours)</p>
          <AreaTrendChart data={stats.activityByDay} color="var(--brand-accent)" />
        </div>
        <div className="card chart-card">
          <p className="card-title">Répartition par catégorie</p>
          {stats.topCategories.length > 0 ? (
            <BarBreakdownChart data={stats.topCategories} />
          ) : (
            <p className="empty-state">Pas encore de catégorie à afficher.</p>
          )}
        </div>
      </div>

      {/* Tableaux */}
      <div >
        <div className="card">
          <p className="card-title">Derniers utilisateurs</p>
          <table className="table">
            <thead>
              <tr className="table-head-row">
                <th>Nom</th>
                <th>Rôle</th>
                <th>Inscription</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {stats.recentUsers.map((u) => (
                <tr key={u.id} className="table-row">
                  <td>
                    <div className="user-name-cell">
                      <span className="avatar-chip">{getUserInitials(u)}</span>
                      <div>
                        <p className="table-primary-text">{u.prenom} {u.nom}</p>
                        <p className="table-secondary-text">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`role-badge ${ROLE_BADGE_CLASS[u.role.nomRole] ?? ''}`}>{u.role.nomRole}</span>
                  </td>
                  <td className="table-secondary-text">{dateFormatter.format(new Date(u.dateCreation))}</td>
                  <td className={u.statut === 'ACTIF' ? 'status-active' : 'status-inactive'}>
                    {u.statut === 'ACTIF' ? 'Actif' : 'Inactif'}
                  </td>
                </tr>
              ))}
              {stats.recentUsers.length === 0 && (
                <tr>
                  <td colSpan={4} className="empty-state">Aucun utilisateur pour le moment.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* <div className="card">
          <p className="card-title">Derniers articles</p>
          <table className="table">
            <thead>
              <tr className="table-head-row">
                <th>Titre</th>
                <th>Catégorie</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {stats.recentArticles.map((article) => (
                <tr key={article.id} className="table-row">
                  <td className="table-primary-text article-title-cell">{article.titre}</td>
                  <td className="table-secondary-text">{CATEGORY_META[article.categorie]?.label ?? article.categorie}</td>
                  <td>
                    <span className={`status-badge ${STATUS_BADGE_CLASS[article.statut]}`}>
                      {STATUS_LABEL[article.statut]}
                    </span>
                  </td>
                </tr>
              ))}
              {stats.recentArticles.length === 0 && (
                <tr>
                  <td colSpan={3} className="empty-state">Aucun article pour le moment.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div> */}
      </div>
    </div>
  );
}